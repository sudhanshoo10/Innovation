package com.innovation.Kafka.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CurrencyExchangeRate {
	
	public CurrencyExchangeRate(String currencySymbol, int amount) {
		super();
		this.currencySymbol = currencySymbol;
		this.amount = amount;
	}
	@Id @GeneratedValue
	private int id;
	private String currencySymbol;
	private int amount;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCurrencySymbol() {
		return currencySymbol;
	}
	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}

}
