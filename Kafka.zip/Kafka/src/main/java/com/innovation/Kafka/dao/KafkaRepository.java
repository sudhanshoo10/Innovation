package com.innovation.Kafka.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.innovation.Kafka.pojo.CurrencyExchangeRate;

@Repository
public interface KafkaRepository extends JpaRepository<CurrencyExchangeRate, Integer>{

}
