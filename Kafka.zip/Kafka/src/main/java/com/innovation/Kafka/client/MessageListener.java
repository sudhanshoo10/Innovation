package com.innovation.Kafka.client;

import java.util.concurrent.CountDownLatch;

import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

import com.innovation.Kafka.pojo.CurrencyExchangeRate;

@Configuration
public  class MessageListener {

    public CountDownLatch currencyLatch = new CountDownLatch(1);

    @KafkaListener(topics = "${currency.topic.name}", containerFactory = "currencyExchangeKafkaListenerContainerFactory")
    public void greetingListener(CurrencyExchangeRate currencyExchange) {
        System.out.println("Recieved greeting message: " + currencyExchange);
        this.currencyLatch.countDown();
    }

}