package com.innovation.Kafka;


import java.util.concurrent.TimeUnit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.innovation.Kafka.client.MessageListener;

@SpringBootApplication
public class KafkaApplication {

    public static void main(String[] args) throws Exception {

        ConfigurableApplicationContext context = SpringApplication.run(KafkaApplication.class, args);

        MessageListener listener = context.getBean(MessageListener.class);
 
        listener.currencyLatch.await(10, TimeUnit.SECONDS);

      //  context.close();
    }






}
