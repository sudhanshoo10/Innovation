package com.innovation.Kafka.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovation.Kafka.dao.KafkaRepository;
import com.innovation.Kafka.pojo.CurrencyExchangeRate;

@Service
public class KafkaService {

	@Autowired
	private KafkaRepository repository;
	
	public void insertCurrencyRate(CurrencyExchangeRate currencyExchangeRate) {
		repository.save(currencyExchangeRate);
		System.out.println("Currency Exchange Rate Saved");
	}
	
	public void retrieveCurrencyRate() {
		List<CurrencyExchangeRate> list= repository.findAll();
		System.out.println("Currency Exchange Rate Saved"+list);
	}
	
}
