package com.innovation.Kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
